  package in.otrail;

  import android.content.Context;
  import android.graphics.*;
  import android.graphics.drawable.GradientDrawable;
  import android.view.*;
  import android.widget.*;
  import org.osmdroid.util.GeoPoint;
  import org.osmdroid.views.MapView;
  import java.util.Locale;
  import java.util.regex.Pattern;

  /** One persistent screen-space bubble anchored above the live dot, including during map rotation. */
  final class GpsBubble extends LinearLayout {
    private final int markerClearance;private final MapView map;private GeoPoint point;private final TextView state,coordinates,address,worship;
    private final android.view.ViewTreeObserver observer;private final android.view.ViewTreeObserver.OnPreDrawListener positioner;
    GpsBubble(Context c,MapView map){
      super(c);
      this.map=map;
      markerClearance=GpsMarkerStyle.selected(c).sizeDp()/2;
      setOrientation(VERTICAL);
      setPadding(dp(7),dp(7),dp(7),dp(7));setElevation(dp(2));
      setBackground(NeonBorderDrawable.panel(this,NeonBorderDrawable.Palette.BRIGHT_ORANGE,UiConfig.NAV_BOX_CORNER_DP));
      state=text(UiConfig.LIVE_BUBBLE_SIZE_SP, UiConfig.LIVE_BUBBLE_SPEED_COLOR);
      ((LayoutParams)state.getLayoutParams()).topMargin=0;
      addView(state);
      View line=new View(c);
      line.setBackgroundColor(UiConfig.LIVE_BUBBLE_TEXT);
      LayoutParams separator=new LayoutParams(-1,dp(1));
      separator.setMargins(1,1,1,1);
      //addView(line,separator);
      coordinates=text(UiConfig.LIVE_BUBBLE_SIZE_SP, UiConfig.LIME);
      address=text(UiConfig.LIVE_BUBBLE_SIZE_SP,UiConfig.LIME);
      address.setSingleLine(false);address.setMaxLines(2);
      address.setEllipsize(android.text.TextUtils.TruncateAt.END);
      worship=text(UiConfig.LIVE_BUBBLE_SIZE_SP,UiConfig.LIME);
      addView(coordinates)
      ;addView(address);
      addView(worship);
      setVisibility(GONE);
      observer=map.getViewTreeObserver();
      positioner=()->{position();return true;};
      observer.addOnPreDrawListener(positioner);
    }

    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    
    private TextView text(int sp,int color){
      TextView v=new TextView(getContext());
      v.setTextColor(color);
      v.setTextSize(sp);
      v.setTypeface(Typeface.create(UiConfig.LIVE_BUBBLE_FONT,UiConfig.BODY_FONT_STYLE));
      v.setIncludeFontPadding(false);
      v.setPadding(0,0,0,0);v.setGravity(android.view.Gravity.CENTER);v.setLineSpacing(0f,1f);v.setFallbackLineSpacing(false);
      LayoutParams p=new LayoutParams(-1,-2);
      p.setMargins(dp(UiConfig.LIVE_BUBBLE_BORDER_DP),0,dp(UiConfig.LIVE_BUBBLE_BORDER_DP),0);
      v.setLayoutParams(p);return v;
    }

    void update(GeoPoint point,CharSequence status,String locality,String temples){this.point=point;setChangedText(state,status);setChangedText(coordinates,String.format(java.util.Locale.US,"%.4f · %.4f",point.getLatitude(),point.getLongitude()));setChangedText(address,locality);((LayoutParams)address.getLayoutParams()).bottomMargin=0;address.setVisibility(locality.isBlank()?GONE:VISIBLE);setChangedText(worship,temples);worship.setVisibility(temples.isBlank()?GONE:VISIBLE);setVisibility(VISIBLE);position();}
    void move(GeoPoint point){this.point=point;setChangedText(coordinates,String.format(java.util.Locale.US,"%.4f · %.4f",point.getLatitude(),point.getLongitude()));position();}
    static String roadLabel(String road) {
      if(road==null||road.isBlank())return "";
      String[] parts=road.split("\\s*·\\s*",2);
      String reference=parts[0].trim();
      boolean expressway=road.toLowerCase(Locale.ROOT).contains("expressway");
      if(expressway)return "Exp:"+(isHighwayReference(reference)?" "+reference:"");
      return isHighwayReference(reference)?reference:road.trim();
    }
    static String status(String speed,String driveDistance) {
      String cleanSpeed=speed==null?"":speed.trim().replaceFirst("^[\\s·]+","");
      return driveDistance==null||driveDistance.isBlank()
          ?cleanSpeed:cleanSpeed+" · "+driveDistance;
    }
    static String location(String locality,String road) {
      String label=roadLabel(road);
      if(label.isBlank())return locality==null?"":locality.trim();
      String result=locality==null?"":locality.trim();
      if(road!=null&&road.contains("·")) {
        String name=road.substring(road.indexOf('·')+1).trim();
        if(!name.isBlank()) {
          String normalizedName=normalize(name);
          StringBuilder retained=new StringBuilder();
          for(String line:result.split("\\n")) {
            if(normalize(line).contains(normalizedName))continue;
            if(retained.length()>0)retained.append('\n');
            retained.append(line.trim());
          }
          result=retained.toString().trim();
        }
      }
      if(!result.contains(label))result+=(result.isBlank()?"":"\n")+label;
      return result;
    }
    private static boolean isHighwayReference(String value) {
      return value.matches("(?i)^(NH|SH|NE|MDR|ODR|NHAI)\\s*[- ]?\\s*[A-Z0-9][A-Z0-9/-]*$");
    }
    private static String normalize(String value) {
      return value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]","");
    }
    private static void setChangedText(TextView view,CharSequence value){if(!android.text.TextUtils.equals(view.getText(),value))view.setText(value);}
    private void position(){if(point==null||getVisibility()!=VISIBLE||map.getWidth()==0)return;int maximum=Math.min(dp(UiConfig.LIVE_BUBBLE_WIDTH_DP),map.getWidth()-dp(16));int natural=0;for(TextView v:new TextView[]{state,coordinates,address})if(v.getVisibility()!=GONE){String[] lines=v.getText().toString().split("\n");for(String line:lines)natural=Math.max(natural,(int)Math.ceil(v.getPaint().measureText(line)));}int width=Math.min(maximum,natural+getPaddingLeft()+getPaddingRight()+dp(2*UiConfig.LIVE_BUBBLE_BORDER_DP+2));if(width<=0)return;android.view.ViewGroup.LayoutParams p=getLayoutParams();if(p!=null&&p.width!=width){p.width=width;setLayoutParams(p);}
    Point screen=map.getProjection().toPixels(point,null);map.getProjection().rotateAndScalePoint(screen.x,screen.y,screen);
    if(screen.x<0||screen.y<0||screen.x>map.getWidth()||screen.y>map.getHeight()){setAlpha(0);return;}setAlpha(1);
    float x=Math.max(dp(8),Math.min(map.getWidth()-width-dp(8),screen.x-width/2f)),y=Math.max(dp(7),screen.y-getHeight()-dp(markerClearance));if(Math.abs(getX()-x)>.5f)setX(x);if(Math.abs(getY()-y)>.5f)setY(y);
  }
  void close(){if(observer.isAlive())observer.removeOnPreDrawListener(positioner);}
}

