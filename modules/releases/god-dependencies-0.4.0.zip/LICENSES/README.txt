GOD toolchain dependencies
ECJ 3.38 EPL-2.0: https://github.com/eclipse-jdt/eclipse.jdt.core
D8 BSD-3-Clause: https://r8.googlesource.com/r8
Apksig Apache-2.0: https://android.googlesource.com/platform/tools/apksig
OpenJDK java.compiler GPLv2 + Classpath Exception: https://openjdk.org/legal/gplv2+ce.html
JGit EDL-1.0: https://www.eclipse.org/jgit/
JSch BSD: https://github.com/mwiede/jsch
SLF4J MIT: https://www.slf4j.org/license.html
JavaEWAH Apache-2.0: https://github.com/lemire/javaewah
Commons Codec Apache-2.0: https://commons.apache.org/proper/commons-codec/
Android platform downloaded directly from Google after license acceptance.
